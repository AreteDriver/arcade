# Capture Plan (20–30s proof-of-identity clip)

## Goal
A short clip that instantly communicates:
- Absurd folklore treated seriously
- Honest telegraph language
- Mastery payoff

## Shot List (in order)
1) Shirime: bow → awkward silence → eye beam → perfect deflect → instant win (8–10s)
2) Tanuki: deceptive visual form → player waits → correct read → punish avoided (8–10s)
3) Oni: clean duel moment → perfect deflect → strike window → final hit (6–8s)

## Rules
- No UI clutter (minimal HUD)
- Keep telegraph cues audible
- No meme editing, no comedic stingers
- Title card: “YOKAI BLADE — The Three Trials”
