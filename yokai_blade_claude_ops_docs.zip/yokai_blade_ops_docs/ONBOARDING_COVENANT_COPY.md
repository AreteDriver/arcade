# First-Run Screen Copy (Controls + Covenant)

## Screen Title
YOKAI BLADE — Covenant

## Controls (minimal)
- Move: __________
- Dodge: __________
- Deflect: __________
- Strike: __________

## Covenant (short)
YOKAI BLADE is a folklore action game about attention and discipline.

You will die.
When you do, the game will show you the truth:
what killed you, and what you should do next.

There are no difficulty settings.
The rules do not change.
You change.

[Start]
