# CHERNOKLINOK — QA Matrix (Risk-Aligned)

## Telegraph Integrity (Blocker)
- Every TelegraphSemantic maps to identical meaning across bosses.
- Fail if any boss uses “special tells” outside semantic system.

## Timing / FPS Stability (Blocker)
- Run attack timing harness at 30/60/120 fps.
- Deflect windows must match spec within tolerance.
- Fail if animation speed changes windows.

## Audio Readability (Blocker)
- Laptop speakers + mono mix: telegraphs readable.
- Stream compression preset: telegraphs readable.
- Fail if music masks threat cues.

## Darkness / Low-Visibility Bosses
- Every major attack has: semantic cue + audio cue.
- Fail if a death is unexplained within 1 second.

## Comedy Safety
- No comedic SFX, camera gags, or mocking death stingers.
- Fail on any parody or wink.

## Content Gate
- No new boss until previous boss passes:
  - 10 consecutive clears
  - 0 unclear deaths in last 20 deaths
  - tuning stable for 48 hours
