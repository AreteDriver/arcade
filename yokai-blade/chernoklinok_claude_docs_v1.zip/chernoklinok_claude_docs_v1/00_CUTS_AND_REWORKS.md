# CHERNOKLINOK — Cuts, Reworks, and “Not Yet” Calls

Source: Chernoklinok boss roster doc. Use this to keep the project shippable without losing the soul.

## A) Keep (Strong, scalable, on-theme)
These bosses are mechanically clear, folklore-true, and scalable within a data-driven framework:

### Tier 1 / Early Game
- Domovoi (respect + basic deflect)
- Bannik (environment + visibility rhythm)
- Kikimora (pursuit pressure; “don’t stall”)

### Tier 2 / Mid Game
- Leshy (deception + spatial disorientation, but semantic truth remains)
- Vodyanoy (water level + platform pressure)
- Poludnitsa (time/heat pressure; “answer by acting”)
- Rusalka (pull mechanics + optional alternate release condition)

### Tier 3 / Late Game (choose subset)
- Baba Yaga (iconic multi-phase)
- Zmey Gorynych (multi-target orchestration with cauterize)

### Tier 4 / End Game (choose 1–2)
- Morana (freeze management + rebirth ending)
- Perun (pure power + precision, oak refuge)

### Final
- Chernobog (visibility / audio truth test, with “light grows” payoff)

## B) Rework (Good ideas, but need discipline)
These are high value, but risky unless constrained:

### Likho (Bad Luck meta-debuff)
Risk: violates “player trust” if it changes core timing/inputs.
Rework:
- Do NOT shrink deflect windows or change input behavior.
- Instead apply *pressure* via:
  - reduced meter gain,
  - increased recovery on missed deflect,
  - UI distortion (cosmetic),
  - “misfortune adds hazard spawns” (telegraphed).
Goal: make it feel like everything goes wrong without changing core semantics.

### Nocnitsa (Fear meter + darkness)
Risk: unfairness if the player can’t read tells.
Rework:
- Fear meter can alter *arena* (light radius), never timing semantics.
- Ensure every major attack has an audio cue + semantic cue.
- “Instant game over” at fear max is too harsh; make it a high-damage punishment + forced reset phase instead.

### Chort (Random dice/cards + bargain)
Risk: randomness undermines mastery.
Rework:
- Dice/cards can be *pseudo-random but readable*:
  - roll is telegraphed,
  - the outcome set is small,
  - player can “rig” outcomes through correct play (deflect order mechanic).
- The pre-fight bargain is great, but must not apply hidden permanent debuffs. Make it:
  - a *known* trade (e.g., “lose 1 max meter segment for +1 revive token”) or cosmetic/memory mode.

### Gamayun (prophecy text / “false futures”)
Risk: “false futures” reads like lying.
Rework:
- If you keep “false futures,” mark them as **possible futures** via distinct semantic (blue shimmer “illusion prophecy”), and they must never punish the player for acting correctly.
- Better: keep prophecy as *cryptic but true*, and increase overlap complexity instead of faking.

## C) Not Yet (Stretch / too expensive for first ship)
These can be DLC, secret mode, or sequel. Keep the lore, defer the build.

### Rod (Primordial creator, non-space, no health bar)
Reason: demands custom rendering/space-warp systems, heavy content reuse scaffolding, and tight narrative gating. Excellent capstone, but expensive.
Plan: ship as post-launch “True Ending” update once core slice is stable.

### Strigoi (4 full forms + execution QTE)
Reason: four distinct movesets is almost four bosses.
Plan: cut to 2 forms (Corpse → Mist) for base game; add Wolf/Owl later.

### Zhar-Ptitsa (chase + morality endings)
Reason: chase systems + branching endings complicate production.
Plan: include later once encounter director + branching reward systems are stable.

## D) Recommended “Base Game” Count
Ship with **10–14 bosses** max. Everything else becomes:
- optional trials,
- post-launch free update,
- paid expansion,
- sequel.

This preserves quality and avoids content dilution.
