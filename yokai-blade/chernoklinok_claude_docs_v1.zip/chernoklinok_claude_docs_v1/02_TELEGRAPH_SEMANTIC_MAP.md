# CHERNOKLINOK — Semantic Telegraph Map (How bosses must use cues)

This enforces “telegraph truth.” These are semantics, not styles.

## Global Semantics
- WHITE_FLASH_1F  => perfect deflect window opens
- RED_GLOW        => undodgeable hazard (positioning only)
- BLUE_SHIMMER    => illusion/glamour (never deals damage)
- LOW_BASS_CUE    => arena-wide threat (always true)
- HIGH_CHIME      => strike window opening (boss vulnerable)

## Boss-by-boss enforcement examples

### Domovoi
- Thrown Objects: standard deflectable (no special semantic needed)
- “Threshold Strike” (the teachable moment): WHITE_FLASH_1F + HIGH_CHIME on success window
- Stove flare: RED_GLOW on hazard zone edge

### Bannik
- Steam Burst (cannot deflect): RED_GLOW + LOW_BASS_CUE (if arena-wide)
- Boiling water arcs: deflectable; WHITE_FLASH_1F only if “perfect return” variant exists
- Full Steam near-blind: must add LOW_BASS_CUE for major threats, never rely on visuals alone

### Kikimora
- Cocoon: RED_GLOW on capture zone/line before it binds
- Thread whip perfect timing: WHITE_FLASH_1F
- Chest Sit (unblockable): RED_GLOW + distinct impact audio, no “gotcha” timing

### Leshy
- Illusion clones: BLUE_SHIMMER at spawn and during fake attacks
- Real Leshy: no shimmer; must have consistent semantic cues
- Tree throw: WHITE_FLASH_1F at deflectable apex, not earlier
- Whirlwind pull: LOW_BASS_CUE if it’s arena-wide suction

### Vodyanoy / Chernobog
- Any “audio-only” warning must still be tied to a semantic cue.
- Darkness is allowed; lying is not.

## Forbidden
- Reassigning meanings per boss
- Adding “special exceptions”
- “Funny” telegraph sounds
