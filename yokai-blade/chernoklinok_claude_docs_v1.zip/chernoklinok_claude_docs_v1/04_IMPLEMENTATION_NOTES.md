# CHERNOKLINOK — Implementation Notes (Engineering Constraints)

## 1) Determinism
- Timing windows are specified in data (ms), executed by a single timeline runner.
- Validate stability at 30/60/120 fps.
- Never bind windows to animation events as the source of truth.

## 2) Visibility / Darkness bosses
Darkness is allowed. Unreadable is not.
- Major attacks must have: semantic cue + audio cue.
- If visuals are reduced, audio cues must strengthen, not weaken.

## 3) “Ritual / appeasement” mechanics
Allowed if:
- Optional and never required to understand base rules.
- No hidden fail states.
- Telegraphed by diegetic feedback (not tutorial text).

Example: Domovoi bread offering is a bonus window, not required.

## 4) Multi-phase bosses
Do not add new systems per phase.
- Phases switch patterns, not mechanics.
- Baba Yaga chase/hut phases are separate systems; keep out of initial slice.

## 5) Alternate endings
Treat as conditional victory triggers with clear diegetic hints.
- Rusalka willow branch is good; ensure discoverability without wiki reliance.
