# CHERNOKLINOK — Vertical Slice Options (Pick One and Commit)

Goal: prove (1) semantic telegraphs, (2) mastery combat, (3) Slavic tone.

## Option A (Best for “folklore + systems”): Domovoi → Bannik → Leshy
- Domovoi: tutorial + respect mechanic + basic deflect
- Bannik: environment/visibility rhythm + audio readability
- Leshy: deception + looping space + “shadow tells”

Pros:
- Demonstrates system breadth without late-game production costs.
- Strong pitch arc: house → bathhouse → forest.

Cons:
- No iconic “headline” boss like Baba Yaga.

## Option B (Best for “headline boss”): Domovoi → Leshy → Baba Yaga (Phase 3 only)
- Domovoi: trust + deflect
- Leshy: deception discipline
- Baba Yaga: pure duel phase (skip chase/hut in slice)

Pros:
- Includes the franchise icon.
- Strong commercial hook.

Cons:
- Requires careful scope control to avoid building chase/hut systems.

## Option C (Best for “mechanical cruelty”): Domovoi → Kikimora → Poludnitsa
- Domovoi: basics + respect
- Kikimora: anti-stall pursuit pressure
- Poludnitsa: time/heat question windows (act to answer)

Pros:
- Clear mechanical escalation.
- Minimal environment tech.

Cons:
- Less “spectacle” for publishers.

### Recommendation
Pick **Option A** for first playable and investor demos.
After Gate completion, extend to **Option B** for publisher-facing slice.
