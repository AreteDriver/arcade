# CHERNOKLINOK — Publisher Risk Mitigation (Slice-Focused)

Chernoklinok is a melee-first shmup with mastery deflection. The genre fails if clarity/fairness slips. Mitigation is systematic:

## 1) Telegraph Truth Layer
Fixed semantic vocabulary (audio + visual). Bosses may disguise appearances, never meanings. Semantic mapping is enforced by tests, preventing “special case” drift.

## 2) Deterministic Timing
Attack windows are data-driven and run on a deterministic timeline. Window stability tested at 30/60/120 fps to prevent hardware-dependent feel changes.

## 3) Audio Readability First
Telegraph audio uses dedicated buses and sidechaining to guarantee cues remain audible even under heavy mix and stream compression.

## 4) Scope Discipline
Slice built from reusable systems, not bespoke one-off mechanics. High-cost systems (chase sequences, Rod non-space fight) deferred until core loop proven.

## 5) Tone Discipline
Humor is deadpan and situational—never parody. Failure feedback remains dignified.

Outcome: A hard game that feels honest, stream-readable, and commercially legible in a mastery niche.
