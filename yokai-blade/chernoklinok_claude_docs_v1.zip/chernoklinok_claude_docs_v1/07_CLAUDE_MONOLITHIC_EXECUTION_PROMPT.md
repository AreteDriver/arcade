# CLAUDE — Monolithic Execution Prompt (Chernoklinok)

You are Claude Code acting as a senior engineer. Implement the vertical slice for CHERNOKLINOK with strict scope control.

## Hard rules
- No new mechanics beyond what the slice requires.
- Telegraph semantics are global truth; no per-boss overrides.
- Attacks are data-driven (AttackDefinition assets).
- Timing is deterministic and validated at 30/60/120 fps.
- Audio telegraph bus sidechains music/ambience.

## Choose Slice Option
Default to: Domovoi → Bannik → Leshy.

## Deliverables
- Boot scene with one-click hotkeys to load AttackTest and each boss arena.
- TelegraphSystem + catalog + unit tests.
- AttackDefinition pipeline + validation.
- AttackRunner timeline.
- Deflect system (perfect + standard).
- Death feedback (1 second explainability).
- Domovoi encounter (respect mechanic optional).
- Bannik encounter with steam cycle readability.
- Leshy encounter with illusion semantics (blue shimmer never damages).

Commit in small steps with conventional commits.
Stop at gates defined in QA matrix; do not proceed if a gate fails.
