# SLAVIC BLADE — Vertical Slice Implementation Spec (Domovoi → Leshy → Baba Yaga)

Senior engineering view: define scope, acceptance criteria, and build order.

## 1) Scope
Deliver a playable slice with:
- Walk-up + inscriptions
- Three boss fights: Domovoi, Leshy, Baba Yaga
- Transitions between arenas
- Core combat loop (deflect, strike window, meter, death feedback)
- Audio telegraph system adhering to invariants

Target runtime: 45–60 minutes.

## 2) Shared Systems Required
- Global Telegraph System (semantic mapping is central and testable)
- Deflect System (perfect + standard, deterministic)
- Strike Window System (high chime + vulnerability state)
- Meter System (no passive regen; mastery-only gain)
- Death Feedback System (1s freeze + attack name + response)

## 3) Encounter Specs

### 3.1 Domovoi — Ritual Trial
**Primary objective:** teach restraint and etiquette.

- Arena: small interior yard / threshold space
- Music: none until commitment
- Behavior:
  - Passive ritual loop (adjusts bread / stove / threshold)
  - If player attacks early:
    - “House punishes” attack (fair tell; no lies)
  - If player waits:
    - Domovoi reveals a single “perfect deflect” strike (win condition)
- Acceptance:
  - Waiting + perfect deflect wins consistently
  - Early aggression is punished clearly (explainable deaths)

### 3.2 Leshy — Deception Trial
**Primary objective:** punish assumptions, enforce semantic trust.

- Arena: forest clearing with shifting geometry illusions
- Visual deception: silhouettes, distance warps, decoy forms
- Semantics never lie (telegraph truth layer unchanged)
- Acceptance:
  - Skilled players succeed by reading semantic cues
  - Telegraph audio remains readable under full mix

### 3.3 Baba Yaga — Truth Trial
**Primary objective:** pure execution; no gimmicks.

- Arena: flat ritual ground
- Phases:
  1) heavy telegraphed attacks (teach respect)
  2) tighter windows + counters
  3) relentless chains (final proof)
- Acceptance:
  - No environmental hazards
  - Losses feel deserved; cues consistent

## 4) Transitions / Beats
- Threshold inscription before Domovoi (proverb)
- “Path That Remembers” between Domovoi and Leshy
- Hut-at-the-edge inscription before Baba Yaga (“Do the task…”)

## 5) Audio Checklist
- Domovoi: minimal ambience, silence as humor
- Leshy: playful rhythm, telegraph cues sacrosanct
- Baba Yaga: sparse motif, heavy foley, no flourish

## 6) Engineering Acceptance Tests
- Unit test: semantic mapping cannot change per boss
- Snapshot tests: deflect window duration equals spec per attack
- Mix test: telegraph bus ducks music during threats
- Death feedback must include (attack_name, response_type)

## 7) Deliverables
- Playable build (PC)
- 10–15 minute capture-ready run
- Tuning table (attack timings/windows)
