# SLAVIC BLADE — Project Checklist + Execution Plan (Claude)

Follow order. Stop at gates.

## Non-negotiables
- Vertical slice only until complete
- No art polish until slice passes QA gates
- Semantic telegraphs never lie
- Comedy is deadpan; no parody sounds
- Death feedback explains within 1 second

## Phased Build
### Phase 1: Domovoi only
- Build Domovoi arena, ritual loop, punish-on-early-attack, perfect-deflect win condition
**Gate:** 10 consecutive clears; 0 unclear deaths

### Phase 2: Leshy
- Visual deception only; semantics remain honest
**Gate:** 10 clears; testers report deaths explainable

### Phase 3: Baba Yaga
- Pure duel, no gimmicks; 3 phases
**Gate:** 5 clears; 0 semantic inconsistencies

## Tooling Required
- Attack Test Harness scene
- Debug overlay
- Telemetry logs (JSONL)
