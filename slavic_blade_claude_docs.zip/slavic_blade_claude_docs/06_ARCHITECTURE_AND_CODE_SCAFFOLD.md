# SLAVIC BLADE — Code + Architecture (Claude Code Share Doc)

This is the same engineering architecture as YOKAI BLADE, with Slavic content IDs.
Keep: data-driven attacks, semantic telegraphs, deterministic timing, invariant tests.

## 0) Engine Recommendation
Unity LTS + URP + Unity Input System.
Start with Unity Audio Mixer buses; FMOD optional later.

## 1) Semantic Telegraphs
Use the same `TelegraphSemantic` enum and central catalog mapping.
No per-boss overrides. Enforce with tests.

## 2) Data-Driven Attacks
`AttackDefinition` ScriptableObject remains identical.
Only change IDs and content tables (Domovoi/Leshy/BabaYaga).

## 3) Vertical Slice Boss IDs
- Domovoi
- Leshy
- BabaYaga

## 4) Example AttackDefinitions (IDs)
- Domovoi_RitualPunish
- Domovoi_ThresholdStrike (PerfectDeflectWindow; win condition)
- Leshy_DecoyRush
- Leshy_CounterStance
- BabaYaga_ScytheSweep
- BabaYaga_MortarCrash
- BabaYaga_FinalChain

## 5) Implementation Plan (same build order)
1) TelegraphSystem + catalog + tests
2) Input buffering/priority
3) AttackDefinition pipeline + validation
4) AttackRunner timeline
5) Deflect system
6) Death feedback
7) EncounterDirector sequencing scenes

## 6) Tests (must exist)
- Semantic mapping test
- Deflect window regression (30/60/120 fps)
- Audio routing: telegraph cues always use TelegraphBus

## 7) Debug Overlay (mandatory)
Show:
- boss state
- attack id
- last semantic
- time since telegraph
- deflect windows active

## 8) Definition of Done (Slice)
- Domovoi→Leshy→BabaYaga playable end-to-end
- No semantic lies
- Death feedback explains failure within 1 second
- Telegraph cues audible on laptop speakers and under stream compression
