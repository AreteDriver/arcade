# SLAVIC BLADE — Boss Proverbs (One-Line Folklore Truths)

Use as shrine inscriptions, loading lines, or whispered diegetic prompts.
These are **truths**, not tutorials.

## Tier 1 — Teaching
- **Domovoi:** “A quiet house keeps sharp knives.”
- **Kikimora:** “Follow every whisper, and you will never sleep.”
- **Sprigganlings:** “Chase one shadow and three will bite your heels.”

## Tier 2 — Skill & Pressure
- **Rusalka:** “Water forgives nothing you do in haste.”
- **Poludnitsa:** “At noon, even pride sweats.”
- **Upyr:** “Hunger is patient; you must be more patient.”
- **Bannik:** “Steam hides the careless, then takes them.”

## Tier 3 — Mastery & Deadpan Absurdity
- **Leshy:** “Certainty is the easiest mask to wear.”
- **Vodyanoy:** “The deep keeps receipts.”
- **Zmey Gorynych:** “One head lies; three heads coordinate.”
- **Koschei:** “Strike the bone and he laughs; strike the reason and he stops.”

## Tier 4 — Divine / Final
- **Baba Yaga:** “Do the task, not the talking.”
- **Morozko:** “Cold does not chase you; it waits where you stand.”

## Final Trial
- **Chernobog (optional):** “If you bargain with night, pay in daylight.”
