# SLAVIC BLADE — Monolithic Build Prompt (Legendary + Folklore-True)

> Single source-of-truth prompt for Claude Code (or any implementation agent).
> Do not summarize. Do not “improve” tone with parody. Keep telegraph honesty absolute.

You are designing **SLAVIC BLADE**, a semi-comical Slavic folklore action game that treats absurdity with sincerity and mastery with reverence.

This game is not ironic.
It is not grimdark cosplay.
It is **folklore-true**.

The world behaves as if everything is normal —
even when a house spirit demands bread at midnight.

---

## CORE PHILOSOPHY

SLAVIC BLADE is about **discipline through the uncanny**.

Every creature is real.
Every superstition has a cost.
Some are terrifying.
Some are ridiculous.
All are dangerous.

The player may laugh —
but the steel must remain steady.

---

## COMBAT FOUNDATION

Combat is built on a **Sacred Loop**:

1. Pressure  
2. Read  
3. Deflect  
4. Exploit  
5. Reset  

Deflection is not defense.  
Deflection is timing, intent, and respect.

---

## GLOBAL TELEGRAPH LANGUAGE (ABSOLUTE)

Telegraphs are semantic truth, not decoration:

- **White flash (1 frame):** perfect deflect window  
- **Red glow:** undodgeable hazard  
- **Blue shimmer:** illusion / glamour (never damages)  
- **Low bass cue:** arena-wide threat  
- **High chime:** strike window opening  

No enemy ever violates this language.  
Comedy does not excuse dishonesty.

---

## METER PHILOSOPHY

- No passive regeneration  
- Meter gained only through mastery actions  
- Meter misuse may trigger punishment states  

Power is granted through understanding, not accumulation.

---

## DEATH AS TEACHER

On death:
- Brief freeze  
- Attack name shown  
- Correct response icon  
- Optional ghost replay of correct action  

No tutorials.  
No narrator.  
Only truth.

---

## BOSS DESIGN PRINCIPLES

- Every boss teaches one clear lesson  
- Absurdity never removes danger  
- Arena pressure is constant  
- Patterns are readable, not random  
- Aggression without understanding is punished  

---

## BOSS ROSTER (SLAVIC CORE)

### Tier 1 — Teaching
- **Domovoi (House Spirit):** patience, etiquette, and restraint
- **Kikimora (Night Weaver):** pressure and hazards; “don’t chase the noise”
- **Leshy’s Sprigganlings:** chase discipline; controlled aggression

### Tier 2 — Skill & Pressure
- **Rusalka:** rhythm under pull/drag; “water punishes panic”
- **Poludnitsa (Lady Midday):** timing under heat/fatigue waves
- **Upyr (Vampiric Dead):** spacing and stamina; “you can’t brute-force hunger”
- **Bannik (Bathhouse Spirit):** environmental tells; steam and silence

### Tier 3 — Mastery & Deadpan Absurdity
- **Leshy (Forest Trickster):** deception that punishes assumption (semantics remain true)
- **Vodyanoy:** multi-zone threat management
- **Zmey Gorynych:** multi-head orchestration (advanced telegraph stacking)
- **Koschei the Deathless:** “kill the idea, not the body” (phylactery logic; no cheap gimmicks)

### Tier 4 — Divine / Final
- **Baba Yaga:** pure mastery duel with ritual pressure (no lies, no gimmicks)
- **Morozko (Frost):** endurance and precise timing under freeze states

### Final Trial
- **Chernobog / The Black God (optional):** culmination of all semantics and discipline

---

## TONE & PRESENTATION

- The world never jokes  
- Characters do not wink  
- Humor is deadpan and situational  
- Superstition is treated as physics  
- Silence is meaningful  
- Rural life is harsh, practical, and strangely funny  

Players should feel they are walking through living folklore —
where a curse can be petty and lethal at the same time.

---

## DESIGN GOAL

Create a game that:
- Feels ancient, harsh, and uncanny  
- Is funny without becoming parody  
- Demands respect  
- Rewards discipline  
- Becomes legendary through coherence  

Build this game as if it will never apologize for its difficulty —
only for its dishonesty.

Begin design, systems, and implementation accordingly.
