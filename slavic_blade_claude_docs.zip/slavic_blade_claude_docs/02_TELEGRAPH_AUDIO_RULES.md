# SLAVIC BLADE — Comedy-Safe Telegraph + Audio Rules (Production Constraints)

Treat these as invariants. Violations are bugs.

## A. Global Telegraph Invariants (Never Broken)

### Telegraph Semantics (absolute)
- **White flash (1 frame)** → Perfect deflect window
- **Red glow** → Undodgeable hazard (movement/positioning only)
- **Blue shimmer** → Illusion/glamour (never damages)
- **Low bass cue** → Arena-wide threat (always true)
- **High chime** → Strike window opening (always true)

**Rule:** Deception may distort *appearance*, never *meaning*.

### Readability SLA
If the player dies, they must answer **“what killed me and what should I do instead”** within 1 second.
If not, the attack is under-telegraphed or semantically inconsistent.

---

## B. Slavic Humor Rules (Deadpan, Not Parody)

### 1) No parody sounds
Forbidden:
- meme stingers, slapstick boings, comedy slides, cartoon VO reactions

Allowed:
- grounded foley
- creaks, wind, distant animals, brittle wood
- breath, cloth, iron, mud
- silence

### 2) Silence is the punchline
Deadpan humor emerges when the world refuses to acknowledge absurdity.

### 3) Telegraph audio is sacred
Deflect/hazard/strike-window cues are never swapped, stylized into jokes, or buried.

### 4) Humor never reduces consequence
A petty curse still kills you. A silly spirit still punishes mistakes.

### 5) Comedy targets assumptions, not reflexes
Tricksters punish guessing, impatience, and overconfidence.
Avoid “gotcha” timing changes. Deceive in *presentation*, not timing.

### 6) Failure is dignified
No mocking fail stings. No “funny death” cues.

---

## C. Audio Mix Requirements

- Dedicated buses: Telegraph / SFX / Music / Ambience
- Sidechain: Telegraph ducks Music + Ambience during threats
- Test on: laptop speakers, mono mix, stream compression
- Accessibility toggles:
  - Enhanced telegraph audio
  - Mono-safe cues
  - Optional telegraph captions

---

## D. Vertical Slice Tone Notes (Domovoi / Leshy / Baba Yaga)

### Domovoi
- Minimal music until the player commits to action.
- Humor is awkward ritual timing, not sound effects.

### Leshy
- Music can be playful, but never comedic.
- Illusions are visual; semantic cues remain truthful.

### Baba Yaga
- Sparse score; percussive ritual motif.
- Every sound is heavy, final, practical.
