# SLAVIC BLADE — Publisher-Ready Vertical Slice Pitch (Domovoi → Leshy → Baba Yaga)

## Slice Overview
- **Slice Name:** The Three Household Laws
- **Duration:** 45–60 minutes
- **Goal:** Prove tonal range, semantic telegraph integrity, and mastery-first combat

This slice demonstrates how SLAVIC BLADE balances harsh folklore, deadpan humor, and high-skill combat without compromising fairness.

## Why This Slice Works
Three consecutive fights each prove a distinct combat philosophy:

1. **Restraint** (Domovoi)  
2. **Discernment** (Leshy)  
3. **Mastery** (Baba Yaga)  

Together they prove the game is strange and funny while remaining lethal and honest.

---

## Boss 1 — Domovoi (Ritual Trial)
- **Tone:** Deadpan, domestic, unsettling
- **Core Lesson:** Read before acting; ritual patience creates openings

**Hook:** A house spirit is not “aggressive by default.” Attacking without etiquette triggers punishment; waiting for the rite reveals the true deflect moment.

**Why it matters:** Instantly communicates confidence, folklore authenticity, and non-verbal teaching.

---

## Transition — The Path That Remembers
The world subtly judges the player’s behavior:
- doors creak at the wrong time
- floorboards “answer” footsteps
- quiet hangs too long

No UI explanation.

---

## Boss 2 — Leshy (Deception Trial)
- **Tone:** Playful, dangerous, psychologically sharp
- **Core Lesson:** Pattern > appearance; assumptions kill

**Hook:** Leshy reshapes forms and distances, but semantic telegraphs remain honest. The player must trust truth-layer cues, not silhouettes.

**Why it matters:** Demonstrates system integrity and stream-readable mastery learning.

---

## Transition — Hut at the Edge
Illusions end. Sound thins. The path becomes straight.
An inscription reads:
> “Do the task, not the talking.”

---

## Boss 3 — Baba Yaga (Truth Trial)
- **Tone:** Severe, ritual, final
- **Core Lesson:** Pure execution under pressure

**Hook:** No gimmicks. No deception. The arena is clean. The duel is real.

**Why it matters:** Proves the combat system stands alone.

---

## Commercial Proof
- Clear niche identity vs. general action titles
- Honest difficulty with readable semantics (high watch value)
- Long-tail mastery potential (speedruns, challenge runs, discourse)
- Distinct folklore setting with memorable tone

## One-line Pitch
**SLAVIC BLADE is a folklore action game where superstition is physics — and every victory is earned.**
