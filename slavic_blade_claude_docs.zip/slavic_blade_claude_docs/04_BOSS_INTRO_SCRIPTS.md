# SLAVIC BLADE — Boss Intro Scripts (Diegetic, Skippable)

Short, sincere, and repeatable. The world never winks.

## Domovoi — House Spirit
**Scene:** A stove glows low. Bread sits on a plate.  
**Action:** A small shadow adjusts the bread precisely, then waits.  
**Line:** “The house notices.”  
**Music:** None until the player moves.

## Kikimora — Night Weaver (optional tier 1)
**Scene:** Threads tremble in a corner.  
**Action:** A chair leg knocks once by itself.  
**Line:** “Don’t follow.”  
**Music:** Thin ticking, like weaving.

## Leshy — Forest Trickster
**Scene:** The trees stand too close.  
**Action:** A familiar figure appears… then its shadow faces the wrong way.  
**Line:** “Are you sure?”  
**Music:** Playful pulse, no parody.

## Baba Yaga — The Witch of the Hut
**Scene:** The hut is still. The air smells of iron and pine tar.  
**Action:** Mortar scrapes stone—one slow circle.  
**Line:** “Work.”  
**Music:** Single ritual drumbeat.

## Koschei — The Deathless (later)
**Scene:** A throne of bones.  
**Action:** He taps a finger as if counting.  
**Line:** “Again.”  
**Music:** Dry, hollow percussion.
